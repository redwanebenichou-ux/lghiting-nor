import { Link } from 'react-router-dom'
import { useAuth } from '../../contexts/AuthContext'
import { Eye } from 'lucide-react'
import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'

const ParentDashboard = () => {
  const { profile } = useAuth()

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900">
            لوحة ولي الأمر
          </h1>
          <p className="text-gray-600 mt-2">أهلاً وسهلاً، {profile?.full_name || 'ولي الأمر'}</p>
        </div>

        <div className="mb-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">أبنائي</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { name: 'أحمد محمد', age: 12, teacher: 'الشيخ أحمد', progress: 65, attendance: 90 },
              { name: 'فاطمة محمد', age: 10, teacher: 'الشيخة عائشة', progress: 78, attendance: 95 }
            ].map((child, index) => (
              <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
                    <span className="text-primary-600 font-semibold">
                      {child.name.split(' ')[0][0]}
                    </span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{child.name}</h3>
                    <p className="text-sm text-gray-600">{child.age} سنة</p>
                  </div>
                </div>
                
                <div className="space-y-3 mb-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">المعلم</span>
                    <span className="text-gray-900 font-medium">{child.teacher}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">نسبة التقدم</span>
                    <span className="text-primary-600 font-medium">{child.progress}%</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">نسبة الحضور</span>
                    <span className="text-green-600 font-medium">{child.attendance}%</span>
                  </div>
                </div>

                <Link
                  to="/progress"
                  className="w-full bg-primary-50 text-primary-600 py-2 rounded-lg hover:bg-primary-100 transition-colors flex items-center justify-center gap-2"
                >
                  <Eye className="h-4 w-4" />
                  عرض التفاصيل
                </Link>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">الحصص القادمة</h2>
            <div className="space-y-3">
              {[
                { child: 'أحمد محمد', teacher: 'الشيخ أحمد', time: 'غداً 07:00 مساءً', type: 'حفظ' },
                { child: 'فاطمة محمد', teacher: 'الشيخة عائشة', time: 'بعد غد 06:00 مساءً', type: 'تجويد' }
              ].map((item, index) => (
                <div key={index} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                  <div>
                    <h3 className="font-semibold text-gray-900">{item.child}</h3>
                    <p className="text-sm text-gray-600">مع {item.teacher} - {item.type}</p>
                  </div>
                  <p className="text-sm text-gray-700">{item.time}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">آخر التقييمات</h2>
            <div className="space-y-3">
              {[
                { child: 'أحمد محمد', date: '١٠ أكتوبر', score: '٩/١٠' },
                { child: 'فاطمة محمد', date: '٠٩ أكتوبر', score: '٩.٥/١٠' }
              ].map((item, index) => (
                <div key={index} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                  <div>
                    <h3 className="font-semibold text-gray-900">{item.child}</h3>
                    <p className="text-sm text-gray-600">{item.date}</p>
                  </div>
                  <span className="bg-primary-100 text-primary-800 px-3 py-1 rounded-full text-sm font-medium">
                    {item.score}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}

export default ParentDashboard
