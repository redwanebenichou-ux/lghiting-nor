import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Clock, Star } from 'lucide-react'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import { useAuth } from '../contexts/AuthContext'

const TeacherDashboard = () => {
  const { profile } = useAuth()
  const [lessonsThisMonth] = useState(24)
  const [averageRating] = useState(4.8)
  const [totalEarnings] = useState(5400)
  const [upcomingLessons] = useState<any[]>([])

  const weeklySchedule = [
    { day: 'الأحد', available: true, lessons: 2 },
    { day: 'الإثنين', available: true, lessons: 1 },
    { day: 'الثلاثاء', available: false, lessons: 0 },
    { day: 'الأربعاء', available: true, lessons: 3 },
    { day: 'الخميس', available: true, lessons: 2 },
    { day: 'الجمعة', available: true, lessons: 1 },
    { day: 'السبت', available: false, lessons: 0 },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">لوحة تحكم المعلم</h1>
          <p className="text-gray-600">مرحباً بك يا {profile?.full_name || 'معلم'}</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center gap-3">
              <div className="bg-primary-100 w-12 h-12 rounded-lg flex items-center justify-center">
                <Clock className="h-6 w-6 text-primary-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{lessonsThisMonth}</p>
                <p className="text-sm text-gray-500">حصص هذا الشهر</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center gap-3">
              <div className="bg-secondary-100 w-12 h-12 rounded-lg flex items-center justify-center">
                <Star className="h-6 w-6 text-secondary-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{averageRating}</p>
                <p className="text-sm text-gray-500">التقييم المتوسط</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center gap-3">
              <div className="bg-accent-100 w-12 h-12 rounded-lg flex items-center justify-center">
                <Star className="h-6 w-6 text-accent-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{totalEarnings} ر.س</p>
                <p className="text-sm text-gray-500">إجمالي الإيرادات</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">الجدول الأسبوعي</h2>
            <Link to="/teacher" className="text-primary-600 hover:text-primary-700 text-sm font-medium">تعديل</Link>
          </div>
          <div className="space-y-3">
            {weeklySchedule.map((day, index) => (
              <div key={index} className={`flex items-center gap-3 p-3 rounded-lg ${day.available ? 'bg-primary-50' : 'bg-gray-100'} ${!day.available ? 'opacity-50' : ''}`}>
                <span className="font-medium text-gray-700 w-20">{day.day}</span>
                <div className="flex-1 h-2 rounded-full bg-gray-200 overflow-hidden">
                  <div className={`h-full ${day.available ? 'bg-primary-600' : 'bg-gray-300'}`} style={{ width: `${(day.lessons / 5) * 100}%` }} />
                </div>
                <span className="text-sm text-gray-500">{day.lessons} حصة</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">الحصص القادمة</h2>
          </div>
          {upcomingLessons.length === 0 ? (
            <div className="p-4 text-center text-gray-500">لا توجد حصص قادمة</div>
          ) : null}
        </div>
      </main>
      <Footer />
    </div>
  )
}

export default TeacherDashboard
